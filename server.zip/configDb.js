const configDb={
    host     : 'localhost',
    user     : 'root',
    password : '',
    database : 'adatbazis_neve',
    multipleStatements :true
  }

module.exports=configDb

